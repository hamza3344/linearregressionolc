﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace simplelinearregression
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> yy = new List<double>();//dependent variable
            List<double> xx = new List<double>();//independent variable
            foreach(string s in textBox1.Text.Split(","))
            {
                yy.Add(double.Parse(s));
            }foreach(string s in textBox2.Text.Split(","))
            {
                xx.Add(double.Parse(s));
            }
            MessageBox.Show(linearregression(yy, xx));
        }
        public string linearregression(List<double> y,List<double> x)
        {
            var squarex = x.Sum(e => Math.Pow(e - x.Average(), 2));
            var xy = x.Zip(y, (first, second) => (first - x.Average()) * (second - y.Average())).Sum();
            double b1 = xy / squarex;
            double b0 = y.Average() - (x.Average() * b1);
            return "Y= " + b1.ToString() + "X + " + b0.ToString();
        }
    }
}
